import Discord from "discord.js";
const { ButtonStyle, TextInputStyle } = Discord;

export default {
  PREFIX: "!", //write a bot prefix
  TOKEN: "MTAxMjY5OTQxODkzNzU0MDY0OA.GCEJGk.iQ9kc4yarN6i9fKyMC5x4cZ6YHOI75Zrm7Vazw",
  ACTIVITY: { NAME: "Ücretsiz Tanıtım > Destek" },
  GUILD_ID: "814531469170311213", //write discord guild id
  TICKET: {
    CHANNEL: "881043107817345055", //write support requests will be opened type the channel id
    CATEGORY: "926512223063511120",
    ARCHIVE_CATEGORY: "928676034948239421",
    MESSAGE: "Minecraft Sunucunuz/Botunuz/Projeniz/Hostinginiz veya Sponsorluk İle İlgili Bilgi Almak İsterseniz Destek Açabilirsiniz, Ayrıca diğer hizmetler içinde mevcuttur.",
    STAFF_ROLES: ["846463778090254427"], //write ticket support role id
    BUTTONS: [
      {
        STYLE: ButtonStyle.Success,
        LABEL: "Talebi Üstlen (Yetkili)",
        EMOTE: "✅",
        ID: "successTicket",
        DISABLED: false,
      },
      {
        STYLE: ButtonStyle.Secondary,
        LABEL: "Talebi Arşivle",
        EMOTE: "🎫",
        ID: "archiveTicket",
        DISABLED: false,
      },
      {
        STYLE: ButtonStyle.Danger,
        LABEL: "Talebi Sil (Devre Dışı)",
        EMOTE: "🎟️",
        ID: "deleteTicket",
        DISABLED: true,
      },
    ],
    QUESTIONS: [
      {
        ID: "name",
        LABEL: "Adınız nedir?",
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 4,
        MAX_LENGTH: 16,
        PLACE_HOLDER: "Adınız.",
        REQUIRED: true,
      },
      {
        ID: "age",
        LABEL: "Sorununz nedir?",
        STYLE: TextInputStyle.Short,
        MIN_LENGTH: 1,
        MAX_LENGTH: 16,
        PLACE_HOLDER: "Soru/Sorununu yaz.",
        REQUIRED: true,
      },
    ],
  },
};
